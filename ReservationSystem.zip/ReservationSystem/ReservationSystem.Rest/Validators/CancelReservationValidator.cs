﻿using FluentValidation;
using ReservationSystem.DomainApi.DTO.CancelReservation;

namespace ReservationSystem.Rest.Validators
{
    public class CancelReservationValidator : AbstractValidator<CancelReservationRequest>
    {
        public CancelReservationValidator()
        {
        }
    }
}
