﻿using FluentValidation;
using ReservationSystem.DomainApi.DTO.AddSlot;
using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Rest.Validators
{
    public class AddSlotValidator : AbstractValidator<AddSlotRequest>
    {
        public AddSlotValidator()
        {
            RuleFor(r => r.EndDate).GreaterThan(r => r.StartDate);
            RuleFor(r => r.StartDate).GreaterThan(DateTime.Now);
            RuleFor(r => r.Price).GreaterThan(0);
            RuleFor(r => r.Price).GreaterThanOrEqualTo(0);
        }
    }
}
