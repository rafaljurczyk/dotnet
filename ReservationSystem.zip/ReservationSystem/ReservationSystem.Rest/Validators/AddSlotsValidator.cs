﻿using FluentValidation;
using ReservationSystem.DomainApi.DTO.AddSlots;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Rest.Validators
{
    public class AddSlotsValidator : AbstractValidator<AddSlotsRequest>
    {
        public AddSlotsValidator()
        {
            RuleFor(r => r.EndTime).GreaterThan(r => r.StartTime);
            RuleFor(r => r.StartTime).GreaterThan(DateTime.Now);
            RuleFor(r => r.Price).GreaterThan(0);
        }
    }
}
