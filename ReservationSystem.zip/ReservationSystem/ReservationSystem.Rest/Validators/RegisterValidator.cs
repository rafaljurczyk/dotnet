﻿using FluentValidation;
using ReservationSystem.DomainApi.DTO.Register;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Rest.Validators
{
    public class RegisterValidator : AbstractValidator<RegisterRequest>
    {
        public RegisterValidator()
        {
            //RuleFor(r => r.SportType).IsInEnum();
            //RuleFor(r => r.EndTime).GreaterThan(r => r.StartTime);
            //RuleFor(r => r.StartTime).GreaterThan(DateTime.Now);
        }
    }
}
