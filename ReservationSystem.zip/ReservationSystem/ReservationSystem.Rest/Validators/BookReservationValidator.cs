﻿using FluentValidation;
using ReservationSystem.DomainApi.DTO.BookReservation;

namespace ReservationSystem.Rest.Validators
{
    public class BookReservationValidator : AbstractValidator<BookReservationRequest>
    {
        public BookReservationValidator()
        {

        }
    }
}
