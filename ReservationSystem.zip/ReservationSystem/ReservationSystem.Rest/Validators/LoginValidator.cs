﻿using FluentValidation;
using ReservationSystem.DomainApi.DTO.Login;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Rest.Validators
{
    public class LoginValidator : AbstractValidator<LoginRequest>
    {
        public LoginValidator()
        {
            //RuleFor(r => r.SportType).IsInEnum();
            //RuleFor(r => r.EndTime).GreaterThan(r => r.StartTime);
            //RuleFor(r => r.StartTime).GreaterThan(DateTime.Now);
        }
    }
}
