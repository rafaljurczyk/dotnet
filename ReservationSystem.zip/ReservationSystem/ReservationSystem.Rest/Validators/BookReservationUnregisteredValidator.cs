﻿using FluentValidation;
using ReservationSystem.DomainApi.DTO.BookReservationUnregistered;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Rest.Validators
{
    public class BookReservationUnregisteredValidator : AbstractValidator<BookReservationUnregisteredRequest>
    {
        public BookReservationUnregisteredValidator()
        {

        }
    }
}
