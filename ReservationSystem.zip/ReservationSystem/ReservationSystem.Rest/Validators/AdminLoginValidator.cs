﻿using FluentValidation;
using ReservationSystem.DomainApi.DTO.AdminLogin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Rest.Validators
{
    public class AdminLoginValidator : AbstractValidator<AdminLoginRequest>
    {
        public AdminLoginValidator()
        {
            //RuleFor(r => r.SportType).IsInEnum();
            //RuleFor(r => r.EndTime).GreaterThan(r => r.StartTime);
            //RuleFor(r => r.StartTime).GreaterThan(DateTime.Now);
        }
    }
}
