﻿using Microsoft.AspNetCore.Mvc;
using ReservationSystem.DomainApi.DTO.AddSlot;
using ReservationSystem.DomainApi.DTO.AddSlots;
using ReservationSystem.DomainApi.Enums;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Rest.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Rest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SlotController : ControllerBase
    {
        private readonly ISlotService _slotService;
        public SlotController(ISlotService slotService)
        {
            _slotService = slotService;
        }

        [HttpPost("addslot")]
        [Produces("application/json")]
        public async Task<ActionResult<AddSlotResponse>> AddSlot(AddSlotRequest request)
        {
            var startTimeToAdd = new TimeSpan(hours: Int32.Parse(request.StartTimeToDecode.Split(':')[0]), minutes: Int32.Parse(request.StartTimeToDecode.Split(':')[1]), 0);
            request.StartDate += startTimeToAdd;

            var endTimeToAdd = new TimeSpan(hours: Int32.Parse(request.EndTimeToDecode.Split(':')[0]), minutes: Int32.Parse(request.EndTimeToDecode.Split(':')[1]), 0);
            request.EndDate += endTimeToAdd;

            #region Validator
            var validator = new AddSlotValidator();
            if (!validator.Validate(request).IsValid)
            {
                return BadRequest(new AddSlotResponse(ErrorCodes.InvalidParameters));
            }
            #endregion

            var response = await _slotService.AddSlot(request);
            return Ok(response);
        }

        
        [HttpPost("addslots")]
        [Produces("application/json")]
        public async Task<ActionResult<AddSlotsResponse>> AddSlots(AddSlotsRequest request)
        {
            var startTimeToAdd = new TimeSpan(hours: Int32.Parse(request.StartTimeToDecode.Split(':')[0]), minutes: Int32.Parse(request.StartTimeToDecode.Split(':')[1]), 0);
            request.StartTime += startTimeToAdd;

            var endTimeToAdd = new TimeSpan(hours: Int32.Parse(request.EndTimeToDecode.Split(':')[0]), minutes: Int32.Parse(request.EndTimeToDecode.Split(':')[1]), 0);
            request.EndTime += endTimeToAdd;

            #region Validator
            var validator = new AddSlotsValidator();
            if (!validator.Validate(request).IsValid)
            {
                return BadRequest(new AddSlotResponse(ErrorCodes.InvalidParameters));
            }
            #endregion

            var response = await _slotService.AddSlots(request);
            return Ok(response);
        }
    }
}
