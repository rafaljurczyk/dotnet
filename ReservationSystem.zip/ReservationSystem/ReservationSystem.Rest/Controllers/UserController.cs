﻿using Microsoft.AspNetCore.Mvc;
using ReservationSystem.DomainApi.DTO.Login;
using ReservationSystem.DomainApi.DTO.Register;
using ReservationSystem.DomainApi.Enums;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Rest.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Rest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly ILoggingService _loggingService;

        public UserController(IUserService userService, ILoggingService loggingService)
        {
            _userService = userService;
            _loggingService = loggingService;
        }

        [HttpPost("login")]
        [Produces("application/json")]
        public async Task<ActionResult<LoginResponse>> Login(LoginRequest request)
        {
            _loggingService.LogTrace($"{System.Reflection.MethodBase.GetCurrentMethod().Name} - Entered controller.");
            
            #region Validator
            var validator = new LoginValidator();
            if (!validator.Validate(request).IsValid)
            {
                return BadRequest(new LoginResponse(ErrorCodes.InvalidParameters));
            }
            #endregion

            var response = await _userService.Login(request);

            return Ok(response);
        }

        [HttpPost("register")]
        [Produces("application/json")]
        public async Task<ActionResult<RegisterResponse>> Register(RegisterRequest request)
        {
            _loggingService.LogTrace($"{System.Reflection.MethodBase.GetCurrentMethod().Name} - Entered controller.");
            
            #region Validator
            var validator = new RegisterValidator();
            if (!validator.Validate(request).IsValid)
            {
                return BadRequest(new RegisterResponse(ErrorCodes.InvalidParameters));
            }
            #endregion

            var response = await _userService.Register(request);

            return Ok(response);
        }
    }
}
