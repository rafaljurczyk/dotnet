﻿using Microsoft.AspNetCore.Mvc;
using ReservationSystem.DomainApi.DTO.AddFacility;
using ReservationSystem.DomainApi.DTO.AddSportSpace;
using ReservationSystem.DomainApi.DTO.AdminLogin;
using ReservationSystem.DomainApi.Enums;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Rest.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Rest.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        private readonly IAdminService _adminService;
        private readonly ILoggingService _loggingService;

        public AdminController(IAdminService adminService, ILoggingService loggingService)
        {
            _adminService = adminService;
            _loggingService = loggingService;
        }

        [HttpPost("adminlogin")]
        [Produces("application/json")]
        public async Task<ActionResult<AdminLoginResponse>> AdminLogin(AdminLoginRequest request)
        {
            #region Validator
            var validator = new AdminLoginValidator();
            if (!validator.Validate(request).IsValid)
            {
                return BadRequest(new AdminLoginResponse(ErrorCodes.InvalidParameters));
            }
            #endregion

            var response = await _adminService.AdminLogin(request);

            return Ok(response);
        }

        [HttpPost("addfacility")]
        [Produces("application/json")]
        public async Task<ActionResult<AddFacilityResponse>> AddFacility(AddFacilityRequest request)
        {
            var response = await _adminService.AddFacility(request);

            return Ok(response);
        }

        [HttpPost("addsportspace")]
        [Produces("application/json")]
        public async Task<ActionResult<AddSportSpaceResponse>> AddSportSpace(AddSportSpaceRequest request)
        {
            var response = await _adminService.AddSportSpace(request);

            return Ok(response);
        }
    }
}
