﻿#pragma warning disable 1591
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ReservationSystem.DomainApi.DTO.BookReservation;
using ReservationSystem.DomainApi.DTO.BookReservationUnregistered;
using ReservationSystem.DomainApi.DTO.CancelReservation;
using ReservationSystem.DomainApi.DTO.GetAllReservations;
using ReservationSystem.DomainApi.DTO.GetAllReservationsByDate;
using ReservationSystem.DomainApi.DTO.GetAvaiableReservations;
using ReservationSystem.DomainApi.DTO.GetClientReservations;
using ReservationSystem.DomainApi.Enums;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.DomainApi.Models;
using ReservationSystem.Rest.Validators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Rest.Controllers
{
    //[ApiExplorerSettings(IgnoreApi = false)]
    [ApiController]
    [Route("api/[controller]")]
    public class ReservationController : ControllerBase
    {
        private readonly IReservationService _reservationService;
        public ReservationController(IReservationService reservationService)
        {
            _reservationService = reservationService;
        }

        [HttpGet("getavailablereservations")]
        [Produces("application/json")]
        public async Task<ActionResult<GetAvaiableReservationsResponse>> SearchReservation()
        {
            var response = await _reservationService.GetAvaiableReservations();
            return Ok(response);
        }

        [HttpPost("getavailablefilteredreservations")]
        [Produces("application/json")]
        public async Task<ActionResult<GetAvaiableReservationsResponse>> SearchReservation(GetAvaiableReservationsRequest request)
        {
            var response = await _reservationService.GetAvaiableReservations();

            var fiteredReservations = new List<ReservationSearchListModel>();
            foreach(var reservation in response.ReservationSearchList)
            {
                if(reservation.StartTime >= request.StartDate && reservation.EndTime <= request.EndDate && reservation.City == request.City && reservation.SportType == reservation.SportType)
                {
                    fiteredReservations.Add(reservation);
                }
            }
            response.ReservationSearchList = fiteredReservations;

            return Ok(response);
        }

        [HttpPost("getallreservations")]
        [Produces("application/json")]
        public async Task<ActionResult<GetAllReservationsResponse>> GetAllReservations(GetAllReservationsRequest request)
        {
            var response = await _reservationService.GetAllReservations(request);

            return Ok(response);
        }

        [HttpPost("getallreservationsbydate")]
        [Produces("application/json")]
        public async Task<ActionResult<GetAllReservationsByDateResponse>> GetAllReservationsByDate(GetAllReservationsByDateRequest request)
        {
            var requestToPass = new GetAllReservationsRequest();
            requestToPass.VendorName = request.VendorName;
            var response = await _reservationService.GetAllReservations(requestToPass);

            var fiteredReservations = new List<VendorReservationSearchListModel>();
            foreach (var reservation in response.ReservationSearchList)
            {

                if (reservation.StartTime >= request.StartDate && reservation.EndTime <= request.EndDate && reservation.City == request.City && reservation.SportType == reservation.SportType)
                {
                    fiteredReservations.Add(reservation);
                }
            }
            response.ReservationSearchList = fiteredReservations;

            return Ok(response);
        }

        [HttpPost("getclientreservations")]
        [Produces("application/json")]
        public async Task<ActionResult<GetClientReservationsResponse>> SearchClientReservation(GetClientReservationsRequest request)
        {
            var response = await _reservationService.GetClientReservations(request);
            return Ok(response);
        }

        [HttpPost("bookreservation")]
        [Produces("application/json")]
        public async Task<ActionResult<BookReservationResponse>> BookReservation(BookReservationRequest request)
        {
            #region Validator
            var validator = new BookReservationValidator();
            if (!validator.Validate(request).IsValid)
            {
                return new BookReservationResponse(ErrorCodes.InvalidParameters);
            }
            #endregion

            var response = await _reservationService.BookReservation(request);
            return Ok(response);
        }

        [HttpPost("bookreservationunregistered")]
        [Produces("application/json")]
        public async Task<ActionResult<BookReservationUnregisteredResponse>> BookReservationUnregistered(BookReservationUnregisteredRequest request)
        {
            #region Validator
            var validator = new BookReservationUnregisteredValidator();
            if (!validator.Validate(request).IsValid)
            {
                return new BookReservationUnregisteredResponse(ErrorCodes.InvalidParameters);
            }
            #endregion

            var response = await _reservationService.BookReservationUnregistered(request);
            return Ok(response);
        }

        [HttpPost("cancelreservation")]
        [Produces("application/json")]
        public async Task<ActionResult<CancelReservationResponse>> CancelReservation(CancelReservationRequest request)
        {
            #region Validator
            var validator = new CancelReservationValidator();
            if (!validator.Validate(request).IsValid)
            {
                return new CancelReservationResponse(ErrorCodes.InvalidParameters);
            }
            #endregion

            var response = await _reservationService.CancelReservation(request);
            return Ok(response);
        }
    }
}
