﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ReservationSystem.DomainApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Persistence.EfConfigurations
{
    public class FacilityConfiguration : IEntityTypeConfiguration<Facility>
    {
        public void Configure(EntityTypeBuilder<Facility> builder)
        {
            builder.HasKey(f => f.Id);
            builder.Property(f => f.Id).HasColumnName("id").HasColumnType("int").ValueGeneratedOnAdd().IsRequired();
            builder.Property(f => f.Name).HasColumnName("name").HasColumnType("varchar(50)").IsRequired();
            builder.Property(f => f.City).HasColumnName("city").HasColumnType("varchar(50)").IsRequired();
            builder.Property(f => f.Street).HasColumnName("street").HasColumnType("varchar(100)").IsRequired();
            builder.Property(f => f.Mail).HasColumnName("mail").HasColumnType("varchar(100)").IsRequired();
            builder.Property(f => f.PhoneNo).HasColumnName("phone_no").HasColumnType("varchar(9)").IsRequired();
            builder.Property(f => f.Description).HasColumnName("description").HasColumnType("varchar(500)");

            builder.HasMany(f => f.SportSpaces).WithOne(s => s.Facility);
        }
    }
}
