﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ReservationSystem.DomainApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Persistence.EfConfigurations
{
    public class AdminConfiguration : IEntityTypeConfiguration<Admin>
    {
        public void Configure(EntityTypeBuilder<Admin> builder)
        {
            builder.HasKey(v => v.Id);
            builder.Property(t => t.Id).HasColumnName("id").HasColumnType("int").ValueGeneratedOnAdd().IsRequired();
            builder.Property(t => t.Email).HasColumnName("email").HasColumnType("varchar(100)").IsRequired();
            builder.Property(t => t.Password).HasColumnName("password").HasColumnType("varchar(30)").IsRequired();
        }
    }
}
