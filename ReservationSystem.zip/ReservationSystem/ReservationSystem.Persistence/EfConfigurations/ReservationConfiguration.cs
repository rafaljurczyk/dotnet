﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ReservationSystem.DomainApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Persistence.EfConfigurations
{
    public class ReservationConfiguration : IEntityTypeConfiguration<Reservation>
    {
        public void Configure(EntityTypeBuilder<Reservation> builder)
        {
            builder.HasKey(r => r.Id);
            builder.Property(r => r.Id).HasColumnName("id").HasColumnType("int").ValueGeneratedOnAdd().IsRequired();
            builder.Property(r => r.StartTime).HasColumnName("start_time").HasColumnType("timestamp").IsRequired();
            builder.Property(r => r.EndTime).HasColumnName("end_time").HasColumnType("timestamp").IsRequired();
            builder.Property(r => r.Status).HasColumnName("status").HasColumnType("boolean").IsRequired();
            builder.Property(r => r.Price).HasColumnName("price").HasColumnType("decimal").IsRequired();
        }
    }
}
