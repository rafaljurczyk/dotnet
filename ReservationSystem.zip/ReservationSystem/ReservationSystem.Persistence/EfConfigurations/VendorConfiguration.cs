﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ReservationSystem.DomainApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Persistence.EfConfigurations
{
    public class VendorConfiguration : IEntityTypeConfiguration<Vendor>
    {
        public void Configure(EntityTypeBuilder<Vendor> builder)
        {
            builder.HasKey(v => v.Id);
            builder.Property(v => v.Id).HasColumnName("id").HasColumnType("int").ValueGeneratedOnAdd().IsRequired();
            builder.Property(v => v.Name).HasColumnName("name").HasColumnType("varchar(50)").IsRequired();

            builder.HasMany(v => v.Facilities).WithOne(f => f.Vendor);
            builder.HasMany(v => v.Admins).WithOne(f => f.Vendor);
        }
    }
}
