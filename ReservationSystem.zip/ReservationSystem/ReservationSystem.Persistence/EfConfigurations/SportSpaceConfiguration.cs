﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ReservationSystem.DomainApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Persistence.EfConfigurations
{
    public class SportSpaceConfiguration : IEntityTypeConfiguration<SportSpace>
    {
        public void Configure(EntityTypeBuilder<SportSpace> builder)
        {
            builder.HasKey(s => s.Id);
            builder.Property(s => s.Id).HasColumnName("id").HasColumnType("int").ValueGeneratedOnAdd().IsRequired();
            builder.Property(s => s.SportType).HasColumnName("sport_type").HasColumnType("int").IsRequired();
            builder.Property(s => s.Description).HasColumnName("description").HasColumnType("varchar(500)").IsRequired();

            builder.HasMany(s => s.Reservations).WithOne(r => r.SportSpace).IsRequired().OnDelete(DeleteBehavior.Restrict);
        }
    }
}
