﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ReservationSystem.DomainApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Persistence.EfConfigurations
{
    public class UnregisteredClientConfiguration : IEntityTypeConfiguration<UnregisteredClient>
    {
        public void Configure(EntityTypeBuilder<UnregisteredClient> builder)
        {
            builder.HasKey(v => v.Id);
            builder.Property(t => t.Id).HasColumnName("id").HasColumnType("int").ValueGeneratedOnAdd().IsRequired();
            builder.Property(t => t.Surname).HasColumnName("surname").HasColumnType("varchar(50)").IsRequired();
            builder.Property(t => t.PhoneNo).HasColumnName("phone_no").HasColumnType("varchar(9)").IsRequired();
            builder.Property(t => t.Email).HasColumnName("email").HasColumnType("varchar(100)").IsRequired();

            builder.HasMany(c => c.Reservations).WithOne(r => r.UnregisteredBooker);
        }
    }
}
