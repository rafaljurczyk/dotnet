﻿using Microsoft.EntityFrameworkCore;
using ReservationSystem.DomainApi.Entities;
using ReservationSystem.Persistence.EfConfigurations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Persistence.Context
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base (options)
        {
        }

        public virtual DbSet<Vendor> Vendor { get; set; }
        public virtual DbSet<Facility> Facility { get; set; }
        public virtual DbSet<SportSpace> SportSpace { get; set; }
        public virtual DbSet<Client> Client { get; set; }
        public virtual DbSet<Reservation> Reservation { get; set; }
        public virtual DbSet<UnregisteredClient> UnregisteredClient { get; set; }
        public virtual DbSet<Admin> Admin { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new VendorConfiguration());
            modelBuilder.ApplyConfiguration(new FacilityConfiguration());
            modelBuilder.ApplyConfiguration(new SportSpaceConfiguration());
            modelBuilder.ApplyConfiguration(new ClientConfiguration());
            modelBuilder.ApplyConfiguration(new ReservationConfiguration());
            modelBuilder.ApplyConfiguration(new UnregisteredClientConfiguration());
            modelBuilder.ApplyConfiguration(new AdminConfiguration());
        }
    }
}
