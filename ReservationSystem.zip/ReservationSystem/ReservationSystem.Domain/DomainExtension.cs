﻿using Microsoft.Extensions.DependencyInjection;
using ReservationSystem.Domain.Services;
using ReservationSystem.DomainApi.IServices;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain
{
    public static class DomainExtension
    {
        public static void AddDomain(this IServiceCollection serviceCollection)
        {
            serviceCollection.AddMediatR(typeof(DomainExtension));
            serviceCollection.AddScoped<ILoggingService, LoggingService>();
            serviceCollection.AddTransient<IReservationService, ReservationService>();
            serviceCollection.AddTransient<ISlotService, SlotService>();
            serviceCollection.AddTransient<IUserService, UserService>();
            serviceCollection.AddTransient<IAdminService, AdminService>();
        }
    }
}
