﻿using MediatR;
using Microsoft.IdentityModel.Tokens;
using ReservationSystem.Domain.Functions.Admin.Query.LoginAdmin;
using ReservationSystem.DomainApi.DTO.AddFacility;
using ReservationSystem.DomainApi.DTO.AddSportSpace;
using ReservationSystem.DomainApi.DTO.AdminLogin;
using ReservationSystem.DomainApi.Entities;
using ReservationSystem.DomainApi.Enums;
using ReservationSystem.DomainApi.Exceptions;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Services
{
    public class AdminService : IAdminService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        private IMediator _mediator;

        public AdminService(ApplicationDbContext context, ILoggingService loggingService, IMediator mediator)
        {
            _context = context;
            _loggingService = loggingService;
            _mediator = mediator;
        }

        public async Task<AddFacilityResponse> AddFacility(AddFacilityRequest request)
        {
            try
            {
                var vendor = _context.Vendor.FirstOrDefault(v => v.Name == request.VendorName);

                if(vendor == null)
                {
                    return new AddFacilityResponse(DomainApi.Enums.ErrorCodes.VendorNotFound);
                }

                var facilityToAdd = new Facility
                (
                    request.Name,
                    request.City,
                    request.Street,
                    request.Mail,
                    request.PhoneNo,
                    description: "nowo powstała placówka",
                    vendor: vendor
                );

                await _context.Facility.AddAsync(facilityToAdd);
                await _context.SaveChangesAsync();

                return new AddFacilityResponse(DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in AddFacility", ex);
            }
        }

        public async Task<AddSportSpaceResponse> AddSportSpace(AddSportSpaceRequest request)
        {
            try
            {
                var facility = _context.Facility.FirstOrDefault(v => v.Name == request.FacilityName);

                if (facility == null)
                {
                    return new AddSportSpaceResponse(DomainApi.Enums.ErrorCodes.FacilityNotFound);
                }

                if(!Enum.TryParse<SportType>(request.SportType, out var enumHelper))
                {
                    throw new ExceptionNotDefined("Problem in AdminLogin");
                }

                var sportSpaceToAdd = new SportSpace
                (
                    enumHelper,
                    request.Description,
                    facility
                );

                await _context.SportSpace.AddAsync(sportSpaceToAdd);
                await _context.SaveChangesAsync();

                return new AddSportSpaceResponse(DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in AddFacility", ex);
            }
        }

        public async Task<AdminLoginResponse> AdminLogin(AdminLoginRequest request)
        {
            try
            {
                var loginAdmin = await _mediator.Send(new LoginAdmin(request.Email, request.Password));

                if (loginAdmin.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new AdminLoginResponse(loginAdmin.ErrorCode);

                var jwtToken = CreateJwt(loginAdmin.Admin);

                return new AdminLoginResponse(jwtToken, DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in AdminLogin", ex);
            }
        }

        private string CreateJwt(Admin admin)
        {
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes("inzynierkarafaljurczyk");
            var identity = new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Name,$"{admin.Email};{admin.Vendor.Name}")
            });

            var credentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = identity,
                Expires = DateTime.Now.AddHours(10),
                SigningCredentials = credentials
            };
            var token = jwtTokenHandler.CreateToken(tokenDescriptor);

            return jwtTokenHandler.WriteToken(token);
        }
    }
}
