﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using ReservationSystem.Domain.Functions.Reservations.Command.BookReservation;
using ReservationSystem.Domain.Functions.Reservations.Query.GetAllAvailableReservations;
using ReservationSystem.Domain.Functions.Reservations.Query.GetReservation;
using ReservationSystem.DomainApi.DTO.BookReservation;
using ReservationSystem.DomainApi.DTO.BookReservationUnregistered;
using ReservationSystem.DomainApi.DTO.CancelReservation;
using ReservationSystem.DomainApi.DTO.GetAllReservations;
using ReservationSystem.DomainApi.DTO.GetAvaiableReservations;
using ReservationSystem.DomainApi.DTO.GetClientReservations;
using ReservationSystem.DomainApi.Entities;
using ReservationSystem.DomainApi.Enums;
using ReservationSystem.DomainApi.Exceptions;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using BookReservationResponse = ReservationSystem.DomainApi.DTO.BookReservation.BookReservationResponse;

namespace ReservationSystem.Domain.Services
{
    public class ReservationService : IReservationService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        private IMediator _mediator;

        public ReservationService(ApplicationDbContext context, ILoggingService loggingService, IMediator mediator)
        {
            _context = context;
            _loggingService = loggingService;
            _mediator = mediator;
        }


        public async Task<GetAvaiableReservationsResponse> GetAvaiableReservations()
        {
            try
            {
                var availableReservations = await _mediator.Send(new GetAllAvailableReservations());

                if (availableReservations.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new GetAvaiableReservationsResponse(availableReservations.ErrorCode);

                return new GetAvaiableReservationsResponse(availableReservations.AvailableReservationList, DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in GetAvaiableReservations", ex);
            }
        }

        public async Task<BookReservationUnregisteredResponse> BookReservationUnregistered(BookReservationUnregisteredRequest request)
        {
            try
            {
                var reservationToBook = await _mediator.Send(new GetReservation(request.ReservationToBook));

                if (reservationToBook.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new BookReservationUnregisteredResponse(reservationToBook.ErrorCode);


                var checkUser = _context.Client.FirstOrDefault(c => c.PhoneNo == request.PhoneNo && c.Email == request.Email);
                var bookResponse = new Functions.Reservations.Command.BookReservation.BookReservationResponse();
                if (checkUser == null)
                {
                    var unregisteredBooker = new UnregisteredClient(request.Surname, request.Email, request.PhoneNo);
                    bookResponse = await _mediator.Send(new Functions.Reservations.Command.BookReservation.BookReservation(reservationToBook.Reservation, unregisteredClient: unregisteredBooker, client: null));
                }
                else
                {
                    bookResponse = await _mediator.Send(new Functions.Reservations.Command.BookReservation.BookReservation(reservationToBook.Reservation, unregisteredClient: null, client: checkUser));
                }



                if (bookResponse.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new BookReservationUnregisteredResponse(bookResponse.ErrorCode);

                return new BookReservationUnregisteredResponse(DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in BookReservation", ex);
            }
        }

        public async Task<BookReservationResponse> BookReservation(BookReservationRequest request)
        {
            try
            {
                var reservationToBook = await _mediator.Send(new GetReservation(request.ReservationToBook));

                if (reservationToBook.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new BookReservationResponse(reservationToBook.ErrorCode);

                var booker = _context.Client.FirstOrDefault(c => c.Email == request.Email && c.PhoneNo == request.PhoneNo);

                var reservationStatus = await _mediator.Send(new Functions.Reservations.Command.BookReservation.BookReservation(reservationToBook.Reservation, unregisteredClient: null, client: booker));

                if (reservationStatus.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new BookReservationResponse(reservationStatus.ErrorCode);

                return new BookReservationResponse(DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in BookReservation", ex);
            }
        }

        public async Task<CancelReservationResponse> CancelReservation(CancelReservationRequest request)
        {
            try
            {
                var reservationToCancel = await _mediator.Send(new Functions.Reservations.Command.CancelReservation.CancelReservation(request.ReservationToCancel, request.Surname, request.Email, request.PhoneNo));

                if (reservationToCancel.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new CancelReservationResponse(reservationToCancel.ErrorCode);

                return new CancelReservationResponse(DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in CancelReservation", ex);
            }
        }

        public async Task<GetClientReservationsResponse> GetClientReservations(GetClientReservationsRequest request)
        {
            try
            {
                var clientReservations = _context.Reservation
                    .Include(r => r.Booker)
                    .Include(r => r.SportSpace)
                    .ThenInclude(s => s.Facility)
                    .Where(r => r.Status == true && r.Booker.Email == request.Email && r.Booker.PhoneNo == request.PhoneNo)
                    .ToList();

                if (clientReservations == null || clientReservations.Count <= 0)
                {
                    return new GetClientReservationsResponse(DomainApi.Enums.ErrorCodes.NoReservationsAvaiable);
                }

                var reservationsToReturn = new List<DomainApi.Models.ReservationSearchListModel>();
                foreach (var clientReservation in clientReservations) // good place to use some optimization
                {
                    var reservationToReturn = new DomainApi.Models.ReservationSearchListModel(
                        clientReservation.StartTime,
                        clientReservation.EndTime,
                        clientReservation.Price,
                        clientReservation.SportSpace.SportType.ToString(),
                        clientReservation.SportSpace.Facility.Name,
                        clientReservation.SportSpace.Facility.City
                        );

                    reservationsToReturn.Add(reservationToReturn);
                }

                return new GetClientReservationsResponse(reservationsToReturn, DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in GetAllReservationsResponse", ex);
            }
        }

        public async Task<GetAllReservationsResponse> GetAllReservations(GetAllReservationsRequest request)
        {
            var allReservations = _context.Reservation
                .Include(r => r.Booker)
                .Include(r => r.UnregisteredBooker)
                .Include(r => r.SportSpace)
                .ThenInclude(s => s.Facility)
                .ThenInclude(f => f.Vendor)
                .Where(r => r.SportSpace.Facility.Vendor.Name == request.VendorName && r.StartTime >= DateTime.Now)
                .ToList();

            if(allReservations == null || allReservations.Count == 0)
            {
                return new GetAllReservationsResponse(ErrorCodes.NoReservationsAvaiable);
            }

            var reservationsToReturn = new List<DomainApi.Models.VendorReservationSearchListModel>();
            foreach (var reserv in allReservations) // good place to use some optimization
            {
                var reservationToReturn = new DomainApi.Models.VendorReservationSearchListModel(
                    reserv.StartTime,
                    reserv.EndTime,
                    reserv.Price,
                    reserv.SportSpace.SportType.ToString(),
                    reserv.SportSpace.Facility.Name,
                    reserv.SportSpace.Facility.City,
                    reserv.Status,
                    reserv.SportSpace.Id
                    );

                if(reserv.Status == true)
                {
                    if(reserv.Booker != null)
                    {
                        reservationToReturn.Email = reserv.Booker.Email;
                        reservationToReturn.PhoneNo = reserv.Booker.PhoneNo;
                    }
                    else
                    {
                        reservationToReturn.Email = reserv.UnregisteredBooker.Email;
                        reservationToReturn.PhoneNo = reserv.UnregisteredBooker.PhoneNo;
                    }
                }

                reservationsToReturn.Add(reservationToReturn);
            }

            return new GetAllReservationsResponse(reservationsToReturn, ErrorCodes.Ok);
        }
    }
}
