﻿using MediatR;
using Microsoft.IdentityModel.Tokens;
using ReservationSystem.Domain.Functions.Client.Command.RegisterUser;
using ReservationSystem.Domain.Functions.Client.Query.CheckIfRegistrationValid;
using ReservationSystem.Domain.Functions.Client.Query.LoginUser;
using ReservationSystem.DomainApi.DTO.Login;
using ReservationSystem.DomainApi.DTO.Register;
using ReservationSystem.DomainApi.Entities;
using ReservationSystem.DomainApi.Exceptions;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Services
{
    public class UserService : IUserService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        private IMediator _mediator;

        public UserService(ApplicationDbContext context, ILoggingService loggingService, IMediator mediator)
        {
            _context = context;
            _loggingService = loggingService;
            _mediator = mediator;
        }

        public async Task<LoginResponse> Login(LoginRequest request)
        {
            try
            {
                var loginUser = await _mediator.Send(new LoginUser(request.Email, request.Password));

                if (loginUser.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new LoginResponse(loginUser.ErrorCode);

                var jwtToken = CreateJwt(loginUser.Client);

                return new LoginResponse(loginUser.Client, jwtToken, DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in Login", ex);
            }
        }

        public async Task<RegisterResponse> Register(RegisterRequest request)
        {
            try
            {
                var checkIfUserExists = await _mediator.Send(new CheckIfRegistrationValid(request.PhoneNo, request.Email));

                if (checkIfUserExists.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new RegisterResponse(checkIfUserExists.ErrorCode);

                var registerUser = await _mediator.Send(
                    new RegisterUser(
                        request.FirstName,
                        request.Surname,
                        request.PhoneNo,
                        request.Email,
                        request.Password));

                if (registerUser.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new RegisterResponse(checkIfUserExists.ErrorCode);

                return new RegisterResponse(DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in Register", ex);
            }
        }

        private string CreateJwt(Client client)
        {
            var jwtTokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes("inzynierkarafaljurczyk");
            var identity = new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Name,$"{client.FirstName};{client.Surname};{client.Email};{client.PhoneNo}")
            });

            var credentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = identity,
                Expires = DateTime.Now.AddHours(10),
                SigningCredentials = credentials
            };
            var token = jwtTokenHandler.CreateToken(tokenDescriptor);

            return jwtTokenHandler.WriteToken(token);
        }
    }
}
