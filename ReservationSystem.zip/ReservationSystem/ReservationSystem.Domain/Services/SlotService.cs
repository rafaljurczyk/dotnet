﻿using MediatR;
using ReservationSystem.Domain.Functions.SportSpace.Query.GetSportSpaceById;
using ReservationSystem.DomainApi.DTO.AddSlot;
using ReservationSystem.DomainApi.DTO.AddSlots;
using ReservationSystem.DomainApi.Entities;
using ReservationSystem.DomainApi.Exceptions;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Services
{
    public class SlotService : ISlotService
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        private IMediator _mediator;
        public SlotService(ApplicationDbContext context, ILoggingService loggingService, IMediator mediator)
        {
            _context = context;
            _loggingService = loggingService;
            _mediator = mediator;
        }
        public async Task<AddSlotResponse> AddSlot(AddSlotRequest request)
        {
            try
            {
                var getSportSpaceResponse = await _mediator.Send(new GetSportSpaceById(request.SportSpaceId));

                if (getSportSpaceResponse.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new AddSlotResponse(getSportSpaceResponse.ErrorCode);

                var slotToAdd = new Reservation();
                slotToAdd.StartTime = request.StartDate;
                slotToAdd.EndTime = request.EndDate;
                slotToAdd.Price = request.Price;
                slotToAdd.Status = false;
                slotToAdd.SportSpace = getSportSpaceResponse.SportSpace;
                slotToAdd.Booker = null;
                slotToAdd.UnregisteredBooker = null;

                await _context.AddAsync(slotToAdd);
                await _context.SaveChangesAsync();

                return new AddSlotResponse(slotToAdd, DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in AddSlot", ex);
            }
        }

        public async Task<AddSlotsResponse> AddSlots(AddSlotsRequest request)
        {
            try
            {
                request.StartTime = request.StartTime.AddHours(1);
                request.EndTime = request.EndTime.AddHours(24);
                request.EndTime = request.EndTime.AddMinutes(59);

                var getSportSpaceResponse = await _mediator.Send(new GetSportSpaceById(request.SportSpaceId));

                if (getSportSpaceResponse.ErrorCode != DomainApi.Enums.ErrorCodes.Ok)
                    return new AddSlotsResponse(getSportSpaceResponse.ErrorCode);

                var dateHelper = request.StartTime.Date;
                var stepHelper = new TimeSpan(hours: 0, minutes: request.SessionTime, seconds: 0);

                while(dateHelper < request.EndTime.Date)
                {
                    var timeHelper = request.StartTime.TimeOfDay;
                    var dayHelper = new DateTime(1,1,1);
                    while (dayHelper + (timeHelper + stepHelper) < new DateTime(1,1,2) && (timeHelper + stepHelper) < request.EndTime.TimeOfDay)
                    {
                        var currentVisitDate = dateHelper + timeHelper;

                        var slotToAdd = new Reservation();
                        slotToAdd.StartTime = currentVisitDate;
                        slotToAdd.EndTime = currentVisitDate + stepHelper;
                        slotToAdd.Price = request.Price;
                        slotToAdd.Status = false;
                        slotToAdd.SportSpace = getSportSpaceResponse.SportSpace;
                        slotToAdd.Booker = null;
                        slotToAdd.UnregisteredBooker = null;

                        await _context.AddAsync(slotToAdd);
                        await _context.SaveChangesAsync();

                        timeHelper += stepHelper;
                    }
                    dateHelper = dateHelper.AddDays(1);
                }
                

                return new AddSlotsResponse(DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in AddSlot", ex);
            }
        }
    }
}
