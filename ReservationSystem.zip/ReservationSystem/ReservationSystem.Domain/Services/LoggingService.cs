﻿using Microsoft.Extensions.Logging;
using ReservationSystem.DomainApi.IServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Services
{
    public class LoggingService : ILoggingService
    {
        private readonly ILogger<LoggingService> _logger;
        public string CallId { get; set; }
        public LoggingService(ILogger<LoggingService> logger)
        {
            _logger = logger;
            CallId = Guid.NewGuid().ToString();
        }

        private string GetHeader()
        {
            return ($"Call ID: {CallId} - \n");
        }

        public void LogCritical(string message)
        {
            _logger.LogCritical($"{GetHeader()}{message}");
        }

        public void LogError(string message)
        {
            _logger.LogError($"{GetHeader()}{message}");
        }

        public void LogInformation(string message)
        {
            _logger.LogInformation($"{GetHeader()}{message}");
        }

        public void LogTrace(string message)
        {
            _logger.LogTrace($"{GetHeader()}{message}");
        }

        public void LogWarning(string message)
        {
            _logger.LogWarning($"{GetHeader()}{message}");
        }

        public void SetContext(string Guid)
        {
            return;
        }
    }
}
