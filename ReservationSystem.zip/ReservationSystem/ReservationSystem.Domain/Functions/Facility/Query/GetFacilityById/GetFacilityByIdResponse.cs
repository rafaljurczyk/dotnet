﻿using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Facility.Query.GetFacilityById
{
    public class GetFacilityByIdResponse
    {
        public ErrorCodes ErrorCode { get; set; }
        public DomainApi.Entities.Facility Facility { get; set; }
        public GetFacilityByIdResponse()
        {
        }
        public GetFacilityByIdResponse(ErrorCodes errorCode)
        {
            ErrorCode = errorCode;
        }
        public GetFacilityByIdResponse(DomainApi.Entities.Facility facility, ErrorCodes errorCode)
        {
            Facility = facility;
            ErrorCode = errorCode;
        }
    }
}
