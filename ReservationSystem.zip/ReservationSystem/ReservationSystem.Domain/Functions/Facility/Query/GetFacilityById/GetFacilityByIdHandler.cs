﻿using MediatR;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Facility.Query.GetFacilityById
{
    public class GetFacilityByIdHandler : IRequestHandler<GetFacilityById, GetFacilityByIdResponse>
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        public GetFacilityByIdHandler(ApplicationDbContext context, ILoggingService loggingService)
        {
            _context = context;
            _loggingService = loggingService;
        }

        public async Task<GetFacilityByIdResponse> Handle(GetFacilityById request, CancellationToken cancellationToken)
        {
            var facilityToReturn = _context.Facility.FirstOrDefault(e => e.Id == request.Id);
            if (facilityToReturn == default)
            {
                return new GetFacilityByIdResponse(DomainApi.Enums.ErrorCodes.FacilityNotFound);
            }

            return new GetFacilityByIdResponse(facilityToReturn, DomainApi.Enums.ErrorCodes.Ok);
        }
    }
}
