﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Facility.Query.GetFacilityById
{
    public class GetFacilityById : IRequest<GetFacilityByIdResponse>
    {
        public int Id { get; set; }
        public GetFacilityById()
        {
        }
        public GetFacilityById(int id)
        {
            Id = id;
        }
    }
}
