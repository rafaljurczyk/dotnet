﻿using MediatR;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.SportSpace.Query.GetSportSpaceById
{
    internal class GetSportSpaceByIdHandler : IRequestHandler<GetSportSpaceById, GetSportByIdResponse>
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        public GetSportSpaceByIdHandler(ApplicationDbContext context, ILoggingService loggingService)
        {
            _context = context;
            _loggingService = loggingService;
        }

        public async Task<GetSportByIdResponse> Handle(GetSportSpaceById request, CancellationToken cancellationToken)
        {
            var sportSpaceToReturn = _context.SportSpace.FirstOrDefault(e => e.Id == request.Id);
            if(sportSpaceToReturn == default)
            {
                return new GetSportByIdResponse(DomainApi.Enums.ErrorCodes.SportSpaceNotFound);
            }

            return new GetSportByIdResponse(sportSpaceToReturn, DomainApi.Enums.ErrorCodes.Ok);
        }
    }
}
