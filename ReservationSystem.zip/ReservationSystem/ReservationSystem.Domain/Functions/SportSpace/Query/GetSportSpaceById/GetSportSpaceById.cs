﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.SportSpace.Query.GetSportSpaceById
{
    public class GetSportSpaceById : IRequest<GetSportByIdResponse>
    {
        public int Id { get; set; }
        public GetSportSpaceById()
        {
        }
        public GetSportSpaceById(int id)
        {
            Id = id;
        }
    }
}
