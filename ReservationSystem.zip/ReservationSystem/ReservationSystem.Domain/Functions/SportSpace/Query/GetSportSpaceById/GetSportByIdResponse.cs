﻿using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.SportSpace.Query.GetSportSpaceById
{
    public class GetSportByIdResponse
    {
        public ErrorCodes ErrorCode { get; set; }
        public DomainApi.Entities.SportSpace SportSpace { get; set; }

        public GetSportByIdResponse()
        {
        }
        public GetSportByIdResponse(ErrorCodes errorCode)
        {
            ErrorCode = errorCode;
        }
        public GetSportByIdResponse(DomainApi.Entities.SportSpace sportSpace, ErrorCodes errorCode)
        {
            SportSpace = sportSpace;
            ErrorCode = errorCode;
        }
    }
}
