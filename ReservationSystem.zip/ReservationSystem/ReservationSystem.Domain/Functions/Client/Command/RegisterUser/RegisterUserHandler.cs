﻿using MediatR;
using ReservationSystem.DomainApi.Exceptions;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Client.Command.RegisterUser
{
    public class RegisterUserHandler : IRequestHandler<RegisterUser, RegisterUserResponse>
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        public RegisterUserHandler(ApplicationDbContext context, ILoggingService loggingService)
        {
            _context = context;
            _loggingService = loggingService;
        }

        public async Task<RegisterUserResponse> Handle(RegisterUser request, CancellationToken cancellationToken)
        {
            try
            {
                var createdClient = new DomainApi.Entities.Client(
                    request.FirstName,
                    request.Surname,
                    request.Password,
                    request.PhoneNo,
                    request.Email);

                await _context.AddAsync(createdClient);
                await _context.SaveChangesAsync();

                return new RegisterUserResponse(DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in RegisterUser", ex);
            }
        }
    }
}
