﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Client.Command.RegisterUser
{
    public class RegisterUser : IRequest<RegisterUserResponse>
    {
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string PhoneNo { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }

        public RegisterUser()
        {
        }

        public RegisterUser(string firstName, string surname, string phoneNo, string email, string password)
        {
            FirstName = firstName;
            Surname = surname;
            PhoneNo = phoneNo;
            Email = email;
            Password = password;
        }
    }
}
