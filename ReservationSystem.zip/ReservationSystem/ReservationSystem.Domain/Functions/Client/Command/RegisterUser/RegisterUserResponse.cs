﻿using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Client.Command.RegisterUser
{
    public class RegisterUserResponse
    {
        public ErrorCodes ErrorCode { get; set; }
        public RegisterUserResponse()
        {
        }
        public RegisterUserResponse(ErrorCodes errorCode)
        {
            ErrorCode = errorCode;
        }
    }
}
