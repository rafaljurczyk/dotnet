﻿using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Client.Query.CheckIfRegistrationValid
{
    public class CheckIfRegistrationValidResponse
    {
        public ErrorCodes ErrorCode { get; set; }
        public CheckIfRegistrationValidResponse()
        {
        }
        public CheckIfRegistrationValidResponse(ErrorCodes errorCode)
        {
            ErrorCode = errorCode;
        }
    }
}
