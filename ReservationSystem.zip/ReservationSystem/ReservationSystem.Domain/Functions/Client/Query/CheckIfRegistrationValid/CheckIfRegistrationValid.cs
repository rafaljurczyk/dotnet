﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Client.Query.CheckIfRegistrationValid
{
    public class CheckIfRegistrationValid : IRequest<CheckIfRegistrationValidResponse>
    {
        public string PhoneNo { get; set; }
        public string Email { get; set; }

        public CheckIfRegistrationValid()
        {
        }

        public CheckIfRegistrationValid(string phoneNo, string email)
        {
            PhoneNo = phoneNo;
            Email = email;
        }
    }
}
