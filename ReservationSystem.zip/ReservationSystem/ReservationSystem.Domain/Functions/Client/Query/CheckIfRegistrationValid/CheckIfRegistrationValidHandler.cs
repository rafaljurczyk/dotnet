﻿using MediatR;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Client.Query.CheckIfRegistrationValid
{
    public class CheckIfRegistrationValidHandler : IRequestHandler<CheckIfRegistrationValid, CheckIfRegistrationValidResponse>
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        public CheckIfRegistrationValidHandler(ApplicationDbContext context, ILoggingService loggingService)
        {
            _context = context;
            _loggingService = loggingService;
        }

        public async Task<CheckIfRegistrationValidResponse> Handle(CheckIfRegistrationValid request, CancellationToken cancellationToken)
        {
            var user = _context.Client.FirstOrDefault(c => c.PhoneNo == request.PhoneNo);
            if(user != null)
            {
                return new CheckIfRegistrationValidResponse(DomainApi.Enums.ErrorCodes.UserAlreadyExists);
            }

            user = _context.Client.FirstOrDefault(c => c.Email == request.Email);
            if (user != null)
            {
                return new CheckIfRegistrationValidResponse(DomainApi.Enums.ErrorCodes.UserAlreadyExists);
            }

            return new CheckIfRegistrationValidResponse(DomainApi.Enums.ErrorCodes.Ok);
        }
    }
}
