﻿using MediatR;
using ReservationSystem.DomainApi.Exceptions;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Client.Query.LoginUser
{
    public class LoginUserHandler : IRequestHandler<LoginUser, LoginUserResponse>
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        public LoginUserHandler(ApplicationDbContext context, ILoggingService loggingService)
        {
            _context = context;
            _loggingService = loggingService;
        }

        public async Task<LoginUserResponse> Handle(LoginUser request, CancellationToken cancellationToken)
        {
            try
            {

                var user = _context.Client.FirstOrDefault(c => c.Email == request.Email);
                if (user == null)
                {
                    return new LoginUserResponse(DomainApi.Enums.ErrorCodes.UserDoesNotExists);
                }

                var loggedUser = _context.Client.FirstOrDefault(c => c.Email == request.Email && c.Password == request.Password);
                if (loggedUser == null)
                {
                    return new LoginUserResponse(DomainApi.Enums.ErrorCodes.IncorrectPassword);
                }

                return new LoginUserResponse(loggedUser, DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in LoginUser", ex);
            }
        }
    }
}
