﻿using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Client.Query.LoginUser
{
    public class LoginUserResponse
    {
        public ErrorCodes ErrorCode { get; set; }
        public DomainApi.Entities.Client Client { get; set; }
        public LoginUserResponse()
        {
        }
        public LoginUserResponse(ErrorCodes errorCode)
        {
            ErrorCode = errorCode;
        }
        public LoginUserResponse(DomainApi.Entities.Client client, ErrorCodes errorCode) : this(errorCode)
        {
            Client = client;
        }
    }
}
