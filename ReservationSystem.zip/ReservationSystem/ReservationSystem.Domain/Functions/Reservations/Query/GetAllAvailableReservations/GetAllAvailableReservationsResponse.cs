﻿using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Reservations.Query.GetAllAvailableReservations
{
    public class GetAllAvailableReservationsResponse
    {
        public ErrorCodes ErrorCode { get; set; }
        public IEnumerable<DomainApi.Models.ReservationSearchListModel> AvailableReservationList { get; set; }
        public GetAllAvailableReservationsResponse()
        {
        }
        public GetAllAvailableReservationsResponse(ErrorCodes errorCode)
        {
            ErrorCode = errorCode;
        }
        public GetAllAvailableReservationsResponse(IEnumerable<DomainApi.Models.ReservationSearchListModel> availableReservationList, ErrorCodes errorCode)
        {
            AvailableReservationList = availableReservationList;
            ErrorCode = errorCode;
        }
    }
}
