﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using ReservationSystem.DomainApi.Exceptions;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Reservations.Query.GetAllAvailableReservations
{
    public class GetAllAvailableReservationsHandler : IRequestHandler<GetAllAvailableReservations, GetAllAvailableReservationsResponse>
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        public GetAllAvailableReservationsHandler(ApplicationDbContext context, ILoggingService loggingService)
        {
            _context = context;
            _loggingService = loggingService;
        }

        public async Task<GetAllAvailableReservationsResponse> Handle(GetAllAvailableReservations request, CancellationToken cancellationToken)
        {
            try
            {
                var availableReservations = _context.Reservation
                    .Include(r => r.SportSpace)
                    .ThenInclude(s => s.Facility)
                    .Where(r => r.Status == false && r.StartTime >= DateTime.Now)
                    .ToList() ;
                if (availableReservations == null || availableReservations.Count <= 0)
                {
                    return new GetAllAvailableReservationsResponse(DomainApi.Enums.ErrorCodes.NoReservationsAvaiable);
                }

                var reservationsToReturn = new List<DomainApi.Models.ReservationSearchListModel>();
                foreach(var availableReservation in availableReservations) // good place to use some optimization
                {
                    var reservationToReturn = new DomainApi.Models.ReservationSearchListModel(
                        availableReservation.StartTime,
                        availableReservation.EndTime,
                        availableReservation.Price,
                        availableReservation.SportSpace.SportType.ToString(),
                        availableReservation.SportSpace.Facility.Name,
                        availableReservation.SportSpace.Facility.City
                        );

                    reservationsToReturn.Add(reservationToReturn);
                }

                return new GetAllAvailableReservationsResponse(reservationsToReturn, DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in GetAllReservationsResponse", ex);
            }
        }
    }
}
