﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Reservations.Query.GetAllAvailableReservations
{
    public class GetAllAvailableReservations : IRequest<GetAllAvailableReservationsResponse>
    {
    }
}
