﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using ReservationSystem.DomainApi.Enums;
using ReservationSystem.DomainApi.Exceptions;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Reservations.Query.GetReservation
{
    public class GetReservationHandler : IRequestHandler<GetReservation, GetReservationResponse>
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        public GetReservationHandler(ApplicationDbContext context, ILoggingService loggingService)
        {
            _context = context;
            _loggingService = loggingService;
        }

        public async Task<GetReservationResponse> Handle(GetReservation request, CancellationToken cancellationToken)
        {
            try
            {
                var reservationToReturn = _context.Reservation
                    .Include(c => c.SportSpace)
                    .ThenInclude(s => s.Facility)
                    .FirstOrDefault(
                    c => c.Status == false &&
                    c.SportSpace.SportType == (SportType)Enum.Parse(typeof(SportType), request.ReservationToSearch.SportType) &&
                    c.StartTime == request.ReservationToSearch.StartTime &&
                    c.EndTime == request.ReservationToSearch.EndTime &&
                    c.SportSpace.Facility.City == request.ReservationToSearch.City &&
                    c.SportSpace.Facility.Name == request.ReservationToSearch.FacilityName
                    );

                if (reservationToReturn == default)
                {
                    return new GetReservationResponse(DomainApi.Enums.ErrorCodes.ReservationNotFound);
                }

                return new GetReservationResponse(reservationToReturn, DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in GetReservationHandler", ex);
            }
        }
    }
}
