﻿using MediatR;
using ReservationSystem.DomainApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Reservations.Query.GetReservation
{
    public class GetReservation : IRequest<GetReservationResponse>
    {
        public ReservationSearchListModel ReservationToSearch { get; set; }

        public GetReservation()
        {
        }

        public GetReservation(ReservationSearchListModel reservationToSearch)
        {
            ReservationToSearch = reservationToSearch;
        }
    }
}
