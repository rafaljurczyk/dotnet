﻿using ReservationSystem.DomainApi.Entities;
using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Reservations.Query.GetReservation
{
    public class GetReservationResponse
    {
        public ErrorCodes ErrorCode { get; set; }
        public DomainApi.Entities.Reservation Reservation { get; set; }
        public GetReservationResponse()
        {
        }
        public GetReservationResponse(ErrorCodes errorCode)
        {
            ErrorCode = errorCode;
        }

        public GetReservationResponse(Reservation reservation, ErrorCodes errorCode) : this(errorCode)
        {
            Reservation = reservation;
        }
    }
}
