﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using ReservationSystem.DomainApi.Enums;
using ReservationSystem.DomainApi.Exceptions;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Reservations.Command.CancelReservation
{
    public class CancelReservationHandler : IRequestHandler<CancelReservation, CancelReservationResponse>
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        public CancelReservationHandler(ApplicationDbContext context, ILoggingService loggingService)
        {
            _context = context;
            _loggingService = loggingService;
        }

        public async Task<CancelReservationResponse> Handle(CancelReservation request, CancellationToken cancellationToken)
        {
            try
            {
                var reservationToReturn = _context.Reservation
                    .Include(c => c.Booker)
                    .Include(c => c.UnregisteredBooker)
                    .Include(c => c.SportSpace)
                    .ThenInclude(s => s.Facility)
                    .FirstOrDefault(
                    c => c.Status == true &&
                    c.StartTime == request.ReservationToCancel.StartTime &&
                    c.EndTime == request.ReservationToCancel.EndTime &&
                    c.SportSpace.Facility.City == request.ReservationToCancel.City &&
                    c.SportSpace.Facility.Name == request.ReservationToCancel.FacilityName &&
                    c.Booker != null ? c.Booker.Email == request.Email : c.UnregisteredBooker.Email == request.Email &&
                    c.Booker != null ? c.Booker.PhoneNo == request.PhoneNo : c.UnregisteredBooker.PhoneNo == request.PhoneNo
                    );

                if (reservationToReturn == default)
                {
                    return new CancelReservationResponse(DomainApi.Enums.ErrorCodes.ReservationNotFound);
                }

                reservationToReturn.Status = false;
                reservationToReturn.Booker = null;
                reservationToReturn.UnregisteredBooker = null;
                await _context.SaveChangesAsync();

                return new CancelReservationResponse(DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in CancelReservationHandler", ex);
            }
        }
    }
}
