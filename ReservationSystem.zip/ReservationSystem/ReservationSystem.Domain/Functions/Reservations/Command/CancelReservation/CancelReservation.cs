﻿using MediatR;
using ReservationSystem.DomainApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Reservations.Command.CancelReservation
{
    public class CancelReservation : IRequest<CancelReservationResponse>
    {
        public ReservationSearchListModel ReservationToCancel { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }

        public CancelReservation()
        {
        }

        public CancelReservation(ReservationSearchListModel reservationToCancel, string surname, string email, string phoneNo)
        {
            ReservationToCancel = reservationToCancel;
            Surname = surname;
            Email = email;
            PhoneNo = phoneNo;
        }
    }
}
