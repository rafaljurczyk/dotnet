﻿using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Reservations.Command.CancelReservation
{
    public class CancelReservationResponse
    {
        public ErrorCodes ErrorCode { get; set; }
        public CancelReservationResponse()
        {
        }
        public CancelReservationResponse(ErrorCodes errorCode)
        {
        }
    }
}
