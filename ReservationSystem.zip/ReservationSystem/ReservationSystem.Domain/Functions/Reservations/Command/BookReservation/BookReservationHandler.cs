﻿using MediatR;
using ReservationSystem.DomainApi.Entities;
using ReservationSystem.DomainApi.Exceptions;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Reservations.Command.BookReservation
{
    public class BookReservationHandler : IRequestHandler<BookReservation, BookReservationResponse>
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        public BookReservationHandler(ApplicationDbContext context, ILoggingService loggingService)
        {
            _context = context;
            _loggingService = loggingService;
        }

        public async Task<BookReservationResponse> Handle(BookReservation request, CancellationToken cancellationToken)
        {
            try
            {
                if(request.UnregisteredClient != null)
                {
                    request.Reservation.UnregisteredBooker = request.UnregisteredClient;
                }
                else
                {
                    request.Reservation.Booker = request.Client;
                }

                request.Reservation.Status = true;
                await _context.SaveChangesAsync();

                return new BookReservationResponse(DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in BookReservationHandler", ex);
            }
        }
    }
}
