﻿using MediatR;
using ReservationSystem.DomainApi.Entities;
using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Reservations.Command.BookReservation
{
    public class BookReservation : IRequest<BookReservationResponse>
    {
        public Reservation Reservation { get; set; }
        public UnregisteredClient? UnregisteredClient { get; set; }
        public DomainApi.Entities.Client? Client { get; set; }

        public BookReservation()
        {
        }
        public BookReservation(Reservation reservation, UnregisteredClient? unregisteredClient, DomainApi.Entities.Client? client)
        {
            Reservation = reservation;
            UnregisteredClient = unregisteredClient;
            Client = client;
        }
    }
}
