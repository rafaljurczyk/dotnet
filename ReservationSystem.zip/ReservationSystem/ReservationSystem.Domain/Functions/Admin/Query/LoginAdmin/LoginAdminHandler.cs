﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using ReservationSystem.DomainApi.Exceptions;
using ReservationSystem.DomainApi.IServices;
using ReservationSystem.Persistence.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Admin.Query.LoginAdmin
{
    public class LoginAdminHandler : IRequestHandler<LoginAdmin, LoginAdminResponse>
    {
        private readonly ApplicationDbContext _context;
        private readonly ILoggingService _loggingService;
        public LoginAdminHandler(ApplicationDbContext context, ILoggingService loggingService)
        {
            _context = context;
            _loggingService = loggingService;
        }

        public async Task<LoginAdminResponse> Handle(LoginAdmin request, CancellationToken cancellationToken)
        {
            try
            {

                var admin = _context.Admin.FirstOrDefault(c => c.Email == request.Email);
                if (admin == null)
                {
                    return new LoginAdminResponse(DomainApi.Enums.ErrorCodes.UserDoesNotExists);
                }

                var loggedAdmin = _context.Admin.Include(a => a.Vendor).FirstOrDefault(c => c.Email == request.Email && c.Password == request.Password);
                if (loggedAdmin == null)
                {
                    return new LoginAdminResponse(DomainApi.Enums.ErrorCodes.IncorrectPassword);
                }

                return new LoginAdminResponse(admin, DomainApi.Enums.ErrorCodes.Ok);
            }
            catch (Exception ex)
            {
                throw new ExceptionNotDefined("Problem in LoginAdmin", ex);
            }
        }
    }
}
