﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.Domain.Functions.Admin.Query.LoginAdmin
{
    public class LoginAdmin : IRequest<LoginAdminResponse>
    {
        public string Email { get; set; }
        public string Password { get; set; }

        public LoginAdmin()
        {
        }

        public LoginAdmin(string email, string password)
        {
            Email = email;
            Password = password;
        }
    }
}
