﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.Enums
{
    public enum SportType
    {
        Squash = 0,
        Tenis  = 1,
        Pływanie = 2,
        PiłkaNożna = 3,
    }
}
