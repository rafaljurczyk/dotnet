﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.Enums
{
    public enum ReservationStatus
    {
        Available = 0,
        Unavailable = 1
    }
}
