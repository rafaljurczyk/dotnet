﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.Enums
{
    public enum ErrorCodes
    {
        Ok = 0,
        InvalidParameters = 1,
        SportSpaceNotFound = 2,
        FacilityNotFound = 3,
        VendorNotFound = 4,
        UserAlreadyExists = 5,
        UserDoesNotExists = 6,
        IncorrectPassword = 7,
        NoReservationsAvaiable = 8,
        ReservationNotFound = 9
    }
}
