﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.IServices
{
    public interface ILoggingService
    {
        public string CallId { get; }
        public void SetContext(string Guid);
        public void LogTrace(string message);
        public void LogInformation(string message);
        public void LogError(string message);
        public void LogWarning(string message);
        public void LogCritical(string message);
    }
}
