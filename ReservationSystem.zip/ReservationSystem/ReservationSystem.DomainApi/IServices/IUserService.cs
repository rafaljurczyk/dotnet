﻿using ReservationSystem.DomainApi.DTO.Login;
using ReservationSystem.DomainApi.DTO.Register;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.IServices
{
    public interface IUserService
    {
        Task<RegisterResponse> Register(RegisterRequest request);
        Task<LoginResponse> Login(LoginRequest request);
    }
}
