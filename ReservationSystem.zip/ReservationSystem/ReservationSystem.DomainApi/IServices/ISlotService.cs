﻿using ReservationSystem.DomainApi.DTO.AddSlot;
using ReservationSystem.DomainApi.DTO.AddSlots;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.IServices
{
    public interface ISlotService
    {
        Task<AddSlotResponse> AddSlot(AddSlotRequest request);
        Task<AddSlotsResponse> AddSlots(AddSlotsRequest request);
    }
}
