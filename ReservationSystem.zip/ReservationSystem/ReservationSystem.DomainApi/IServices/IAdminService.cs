﻿using ReservationSystem.DomainApi.DTO.AddFacility;
using ReservationSystem.DomainApi.DTO.AddSportSpace;
using ReservationSystem.DomainApi.DTO.AdminLogin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.IServices
{
    public interface IAdminService
    {
        Task<AdminLoginResponse> AdminLogin(AdminLoginRequest request);
        Task<AddFacilityResponse> AddFacility(AddFacilityRequest request);
        Task<AddSportSpaceResponse> AddSportSpace(AddSportSpaceRequest request);
    }
}
