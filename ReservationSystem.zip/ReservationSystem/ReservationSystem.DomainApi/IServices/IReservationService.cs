﻿using ReservationSystem.DomainApi.DTO.BookReservation;
using ReservationSystem.DomainApi.DTO.BookReservationUnregistered;
using ReservationSystem.DomainApi.DTO.CancelReservation;
using ReservationSystem.DomainApi.DTO.GetAllReservations;
using ReservationSystem.DomainApi.DTO.GetAvaiableReservations;
using ReservationSystem.DomainApi.DTO.GetClientReservations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.IServices
{
    public interface IReservationService
    {
        Task<GetAvaiableReservationsResponse> GetAvaiableReservations();
        Task<GetAllReservationsResponse> GetAllReservations(GetAllReservationsRequest request);
        Task<GetClientReservationsResponse> GetClientReservations(GetClientReservationsRequest request);
        Task<BookReservationUnregisteredResponse> BookReservationUnregistered(BookReservationUnregisteredRequest request);
        Task<BookReservationResponse> BookReservation(BookReservationRequest request);
        Task<CancelReservationResponse> CancelReservation(CancelReservationRequest request);
    }
}
