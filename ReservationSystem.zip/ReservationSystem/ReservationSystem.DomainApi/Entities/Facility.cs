﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.Entities
{
    public class Facility
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public string Street { get; set; }
        public string Mail { get; set; }
        public string PhoneNo { get; set; }
        public string Description { get; set; }
        public Vendor Vendor { get; set; }
        public virtual IEnumerable<SportSpace> SportSpaces { get; set; }

        public Facility()
        {
        }

        public Facility(string name, string city, string street, string mail, string phoneNo, string description, Vendor vendor)
        {
            Name = name;
            City = city;
            Street = street;
            Mail = mail;
            PhoneNo = phoneNo;
            Description = description;
            Vendor = vendor;
        }
    }
}
