﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.Entities
{
    public class UnregisteredClient
    {
        public int Id { get; set; }
        public string Surname { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
        public IEnumerable<Reservation> Reservations { get; set; }

        public UnregisteredClient()
        {
        }

        public UnregisteredClient(string surname, string email, string phoneNo)
        {
            Surname = surname;
            Email = email;
            PhoneNo = phoneNo;
        }

        public UnregisteredClient(int id, string surname, string email, string phoneNo, IEnumerable<Reservation> reservations)
        {
            Id = id;
            Surname = surname;
            Email = email;
            PhoneNo = phoneNo;
            Reservations = reservations;
        }
    }
}
