﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.Entities
{
    public class Client
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string Surname { get; set; }
        public string Password { get; set; }
        public string PhoneNo { get; set; }
        public string Email { get; set; }
        public IEnumerable<Reservation> Reservations { get; set; }

        public Client()
        {
        }

        public Client(string firstName, string surname, string password, string phoneNo, string email)
        {
            FirstName = firstName;
            Surname = surname;
            Password = password;
            PhoneNo = phoneNo;
            Email = email;
        }
    }
}
