﻿using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.Entities
{
    public class SportSpace
    {
        public int Id { get; set; }
        public SportType SportType { get; set; }
        public string Description { get; set; }
        public Facility Facility { get; set; }
        public virtual IEnumerable<Reservation> Reservations { get; set; }

        public SportSpace()
        {
        }

        public SportSpace(SportType sportType, string description, Facility facility)
        {
            SportType = sportType;
            Description = description;
            Facility = facility;
        }
    }
}
