﻿using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.Entities
{
    public class Reservation
    {
        public int Id { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public bool Status { get; set; } // możliwe rozszerzenie na enum ReservationStatus
        public float Price { get; set; }
        public Client? Booker { get; set; }
        public UnregisteredClient? UnregisteredBooker { get; set; }
        public SportSpace SportSpace { get; set; }

        public Reservation()
        {
        }

        public Reservation(int id, DateTime startTime, DateTime endTime, bool status, float price, SportSpace sportSpace)
        {
            Id = id;
            StartTime = startTime;
            EndTime = endTime;
            Status = status;
            Price = price;
            SportSpace = sportSpace;
        }

        public Reservation(int id, DateTime startTime, DateTime endTime, bool status, float price, Client? booker, UnregisteredClient? unregisteredBooker, SportSpace sportSpace)
        {
            Id = id;
            StartTime = startTime;
            EndTime = endTime;
            Status = status;
            Price = price;
            Booker = booker;
            UnregisteredBooker = unregisteredBooker;
            SportSpace = sportSpace;
        }


    }
}
