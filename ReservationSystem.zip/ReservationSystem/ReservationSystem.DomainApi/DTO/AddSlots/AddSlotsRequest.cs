﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.AddSlots
{
    public class AddSlotsRequest
    {
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public string StartTimeToDecode { get; set; }
        public string EndTimeToDecode { get; set; }
        public int SessionTime { get; set; }
        public float Price { get; set; }
        public int SportSpaceId { get; set; }
    }
}
