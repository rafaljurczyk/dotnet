﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.GetAllReservationsByDate
{
    public class GetAllReservationsByDateRequest
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string City { get; set; }
        public string SportType { get; set; }
        public string VendorName { get; set; }
    }
}
