﻿using ReservationSystem.DomainApi.DTO.Generic;
using ReservationSystem.DomainApi.Enums;
using ReservationSystem.DomainApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.GetAllReservationsByDate
{
    public class GetAllReservationsByDateResponse : BaseResponse
    {
        public IEnumerable<VendorReservationSearchListModel> ReservationSearchList { get; set; }
        public GetAllReservationsByDateResponse(ErrorCodes errorCode) : base(errorCode)
        {
        }
        public GetAllReservationsByDateResponse(IEnumerable<VendorReservationSearchListModel> reservationSearchList, ErrorCodes errorCode) : base(errorCode)
        {
            ReservationSearchList = reservationSearchList;
        }
    }
}
