﻿using ReservationSystem.DomainApi.DTO.Generic;
using ReservationSystem.DomainApi.Entities;
using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.ChangeFacilityDescription
{
    public class ChangeFacilityDescriptionResponse : BaseResponse
    {
        public Facility Facility { get; set; }
        public ChangeFacilityDescriptionResponse(ErrorCodes errorCode) : base(errorCode)
        {
        }
        public ChangeFacilityDescriptionResponse(Facility facility, ErrorCodes errorCode) : base(errorCode)
        {
            Facility = facility;
        }
    }
}
