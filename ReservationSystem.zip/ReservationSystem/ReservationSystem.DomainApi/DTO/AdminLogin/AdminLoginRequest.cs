﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.AdminLogin
{
    public class AdminLoginRequest
    {
        public string Email { get; set; }
        public string Password { get; set; }

        public AdminLoginRequest()
        {
        }

        public AdminLoginRequest(string email, string password)
        {
            Email = email;
            Password = password;
        }
    }
}
