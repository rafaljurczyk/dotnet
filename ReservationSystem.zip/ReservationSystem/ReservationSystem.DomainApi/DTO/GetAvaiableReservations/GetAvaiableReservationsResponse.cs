﻿using ReservationSystem.DomainApi.DTO.Generic;
using ReservationSystem.DomainApi.Enums;
using ReservationSystem.DomainApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.GetAvaiableReservations
{
    public class GetAvaiableReservationsResponse : BaseResponse
    {
        public IEnumerable<ReservationSearchListModel> ReservationSearchList { get; set; }
        public GetAvaiableReservationsResponse(ErrorCodes errorCode) : base(errorCode)
        {
        }

        public GetAvaiableReservationsResponse(IEnumerable<ReservationSearchListModel> reservationSearchList, ErrorCodes errorCode) : base(errorCode)
        {
            ReservationSearchList = reservationSearchList;
        }
    }
}
