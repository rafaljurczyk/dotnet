﻿using ReservationSystem.DomainApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.AddSportSpace
{
    public class AddSportSpaceRequest
    {
        public string SportType { get; set; }
        public string Description { get; set; }
        public string FacilityName { get; set; }
    }
}
