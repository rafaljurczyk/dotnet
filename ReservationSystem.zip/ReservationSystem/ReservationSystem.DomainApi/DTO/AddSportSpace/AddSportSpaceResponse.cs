﻿using ReservationSystem.DomainApi.DTO.Generic;
using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.AddSportSpace
{
    public class AddSportSpaceResponse : BaseResponse
    {
        public AddSportSpaceResponse(ErrorCodes errorCode) : base(errorCode)
        {
        }
    }
}
