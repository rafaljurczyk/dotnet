﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.GetClientReservations
{
    public class GetClientReservationsRequest
    {
        public string Surname { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
    }
}
