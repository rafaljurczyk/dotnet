﻿using ReservationSystem.DomainApi.DTO.Generic;
using ReservationSystem.DomainApi.Enums;
using ReservationSystem.DomainApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.GetClientReservations
{
    public class GetClientReservationsResponse : BaseResponse
    {
        public IEnumerable<ReservationSearchListModel> ReservationSearchList { get; set; }
        public GetClientReservationsResponse(ErrorCodes errorCode) : base(errorCode)
        {
        }

        public GetClientReservationsResponse(IEnumerable<ReservationSearchListModel> reservationSearchList, ErrorCodes errorCode) : base(errorCode)
        {
            ReservationSearchList = reservationSearchList;
        }
    }
}
