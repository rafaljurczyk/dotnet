﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.GetAllReservations
{
    public class GetAllReservationsRequest
    {
        public string VendorName { get; set; }
    }
}
