﻿using ReservationSystem.DomainApi.DTO.Generic;
using ReservationSystem.DomainApi.Entities;
using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.Login
{
    public class LoginResponse : BaseResponse
    {
        public Client Client { get; set; }
        public string Token { get; set; }
        public LoginResponse(ErrorCodes errorCode) : base(errorCode)
        {

        }

        public LoginResponse(Client client, ErrorCodes errorCode) : base(errorCode)
        {
            Client = client;
        }

        public LoginResponse(Client client, string token, ErrorCodes errorCode) : base(errorCode)
        {
            Client = client;
            Token = token;
        }
    }
}
