﻿using ReservationSystem.DomainApi.DTO.Generic;
using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.BookReservation
{
    public class BookReservationResponse : BaseResponse
    {

        public BookReservationResponse(ErrorCodes errorCode) : base(errorCode)
        {
        }

        public BookReservationResponse()
        {
        }
    }
}
