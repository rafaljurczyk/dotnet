﻿using ReservationSystem.DomainApi.DTO.Generic;
using ReservationSystem.DomainApi.Entities;
using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.AddSlot
{
    public class AddSlotResponse : BaseResponse
    {
        public AddSlotResponse(ErrorCodes errorCode) : base(errorCode)
        {

        }

        public AddSlotResponse(Reservation reservation, ErrorCodes errorCode) : base(errorCode)
        {
            Id = reservation.Id;
            StartTime = reservation.StartTime;
            EndTime = reservation.EndTime;
            Status = reservation.Status;
            Price = reservation.Price;
            SportType = reservation.SportSpace.SportType;
            SportSpaceId = reservation.SportSpace.Id;

        }

        public int Id { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public bool Status { get; set; }
        public float Price { get; set; }
        public SportType SportType { get; set; }
        public int SportSpaceId { get; set; }
    }
}
