﻿using ReservationSystem.DomainApi.Entities;
using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.AddSlot
{
    public class AddSlotRequest
    {
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string StartTimeToDecode { get; set; }
        public string EndTimeToDecode { get; set; }
        public float Price { get; set; }
        public int SportSpaceId { get; set; }
    }
}
