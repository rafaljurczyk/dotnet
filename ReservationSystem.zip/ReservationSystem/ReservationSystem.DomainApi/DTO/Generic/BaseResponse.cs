﻿using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.DTO.Generic
{
    public class BaseResponse
    {
        public ErrorCodes ErrorCode { get; private set; }
        public BaseResponse(ErrorCodes errorCode)
        {
            ErrorCode = errorCode;
        }

        public BaseResponse()
        {
        }
    }
}
