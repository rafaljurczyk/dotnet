﻿using ReservationSystem.DomainApi.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.Models
{
    public class ReservationSearchListModel
    {
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public float Price { get; set; }
        public string SportType { get; set; }
        public string FacilityName { get; set; }
        public string City { get; set; }

        public ReservationSearchListModel()
        {
        }

        public ReservationSearchListModel(DateTime startTime, DateTime endTime, float price, string sportType, string facilityName, string city)
        {
            StartTime = startTime;
            EndTime = endTime;
            Price = price;
            SportType = sportType;
            FacilityName = facilityName;
            City = city;
        }
    }
}
