﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReservationSystem.DomainApi.Models
{
    public class VendorReservationSearchListModel
    {
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }
        public float Price { get; set; }
        public string SportType { get; set; }
        public string FacilityName { get; set; }
        public string City { get; set; }
        public bool Status { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
        public int SportSpace { get; set; }

        public VendorReservationSearchListModel()
        {
        }
        public VendorReservationSearchListModel(DateTime startTime, DateTime endTime, float price, string sportType, string facilityName, string city, bool status, int sportSpace)
        {
            StartTime = startTime;
            EndTime = endTime;
            Price = price;
            SportType = sportType;
            FacilityName = facilityName;
            City = city;
            Status = status;
            SportSpace = sportSpace;
        }
    }
}
